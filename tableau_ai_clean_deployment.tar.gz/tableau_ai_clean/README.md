# Tableau AI Generator

🚀 **AI-Powered Tableau Workbook Generator** - Transform natural language into professional Tableau workbooks

## ✨ Features

- **Upload Tableau Files** - Support for TWB, TWBX, and HYPER files
- **AI Generation** - Create workbooks from natural language prompts
- **Smart Analysis** - Automatic data structure and pattern recognition
- **Download Management** - Access and manage generated workbooks
- **Modern UI** - Responsive React interface with Tailwind CSS

## 📁 Project Structure

```
tableau-ai-generator/
├── src/                     # React frontend source
│   ├── components/          # React components
│   │   ├── ui/              # shadcn/ui components
│   │   ├── Header.jsx       # Navigation header
│   │   ├── Dashboard.jsx    # Main dashboard
│   │   ├── WorkbookUpload.jsx
│   │   ├── AIGenerator.jsx
│   │   └── GeneratedWorkbooks.jsx
│   ├── assets/              # Static assets
│   └── App.jsx              # Main application
├── api/                     # Serverless API functions
│   ├── health.py            # Health check endpoint
│   ├── stats.py             # Statistics endpoint
│   ├── upload.py            # File upload handler
│   ├── generate.py          # AI generation endpoint
│   ├── generated.py         # List generated workbooks
│   ├── download/[id].py     # Download workbook
│   └── workbooks/[id].py    # Delete workbook
├── dist/                    # Built frontend (after npm run build)
├── vercel.json              # Vercel configuration
├── package.json             # Frontend dependencies
├── requirements.txt         # Python dependencies
└── README.md                # This file
```

## 🚀 Quick Deploy to Vercel

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/tableau-ai-generator.git
git push -u origin main
```

### 2. Deploy to Vercel
1. Go to [vercel.com](https://vercel.com) → "New Project"
2. Import your GitHub repository
3. Click "Deploy" (Vercel auto-detects everything)
4. Get your live URL: `https://tableau-ai-generator.vercel.app`

### 3. Configure Environment (Optional)
Add your OpenAI API key in Vercel dashboard:
- Go to Project Settings → Environment Variables
- Add: `OPENAI_API_KEY` = `your_api_key_here`

## 🛠️ Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## 🎯 API Endpoints

- `GET /api/health` - Health check
- `GET /api/stats` - Application statistics
- `POST /api/upload` - Upload Tableau files
- `POST /api/generate` - Generate workbooks from prompts
- `GET /api/generated` - List generated workbooks
- `GET /api/download/[id]` - Download workbook

## 🔧 Technology Stack

- **Frontend**: React 18, Tailwind CSS, shadcn/ui
- **Backend**: Python Flask (Serverless Functions)
- **Deployment**: Vercel (Frontend + Backend)
- **AI**: OpenAI GPT-4 (Optional)

## 📝 License

MIT License - Feel free to use and modify!

