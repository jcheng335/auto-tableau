from http.server import BaseHTTPRequestHandler
import json
from urllib.parse import urlparse, parse_qs

# Global storage for demo purposes (in production, use a database)
generated_workbooks = []

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            # Extract workbook ID from path
            path = urlparse(self.path).path
            workbook_id = int(path.split('/')[-1])
            
            # Find workbook
            workbook = next((wb for wb in generated_workbooks if wb['id'] == workbook_id), None)
            if not workbook:
                self.send_error(404, 'Workbook not found')
                return
            
            # Create a simple TWB file content for demo
            twb_content = f'''<?xml version='1.0' encoding='utf-8' ?>
<workbook version='18.1' xmlns:user='http://www.tableausoftware.com/xml/user'>
  <document-format-change-manifest>
    <_.fcp.ObjectModelEncapsulateLegacy.true...ObjectModelEncapsulateLegacy>
    <_.fcp.ObjectModelTableType.true...ObjectModelTableType>
    <_.fcp.SchemaViewerObjectModel.true...SchemaViewerObjectModel>
  </document-format-change-manifest>
  <preferences>
    <preference name='ui.encoding.shelf.height' value='24' />
    <preference name='ui.shelf.height' value='26' />
  </preferences>
  <datasources>
    <datasource caption='Generated Data' inline='true' name='federated.1234567890' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='Sample Data' name='textscan.1234567890'>
            <connection class='textscan' directory='' filename='sample_data.csv' password='' server='' />
          </named-connection>
        </named-connections>
      </connection>
    </datasource>
  </datasources>
  <worksheets>
    <worksheet name='Generated Chart'>
      <table>
        <view>
          <datasources>
            <datasource caption='Generated Data' name='federated.1234567890' />
          </datasources>
        </view>
      </table>
    </worksheet>
  </worksheets>
  <dashboards>
    <dashboard name='Generated Dashboard'>
      <style />
      <size maxheight='800' maxwidth='1000' minheight='600' minwidth='750' />
      <zones>
        <zone h='100000' id='4' type='layout-basic' w='100000' x='0' y='0'>
          <zone h='98400' id='5' param='[federated.1234567890]' type='worksheet' w='98400' x='800' y='800'>
            <zone name='Generated Chart' />
          </zone>
        </zone>
      </zones>
    </dashboard>
  </dashboards>
  <windows>
    <window class='dashboard' name='Generated Dashboard'>
      <viewpoints />
    </window>
  </windows>
</workbook>'''
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/xml')
            self.send_header('Content-Disposition', f'attachment; filename="{workbook["name"]}.twb"')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            self.wfile.write(twb_content.encode('utf-8'))
            
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            error_response = {'error': str(e)}
            self.wfile.write(json.dumps(error_response).encode())

