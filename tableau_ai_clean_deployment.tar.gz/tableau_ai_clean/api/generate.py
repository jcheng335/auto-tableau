from http.server import BaseHTTPRequestHandler
import json
from datetime import datetime

# Global storage for demo purposes (in production, use a database)
generated_workbooks = []

class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        return

    def do_POST(self):
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            
            prompt = data.get('prompt', '').strip()
            if not prompt:
                self.send_error(400, 'Prompt is required')
                return
            
            # Simulate AI generation
            workbook = {
                'id': len(generated_workbooks) + 1,
                'name': f'Generated_Workbook_{len(generated_workbooks) + 1}',
                'prompt': prompt,
                'createdAt': datetime.now().isoformat(),
                'status': 'completed',
                'visualizations': 2,  # Simulated
                'size': f'{round(2.5 + len(prompt) * 0.01, 1)}MB',
                'downloadUrl': f'/api/download/{len(generated_workbooks) + 1}'
            }
            
            generated_workbooks.append(workbook)
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.end_headers()
            
            response = {
                'success': True,
                'workbook': workbook,
                'message': 'Workbook generated successfully'
            }
            
            self.wfile.write(json.dumps(response).encode())
            
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            error_response = {'error': str(e)}
            self.wfile.write(json.dumps(error_response).encode())

