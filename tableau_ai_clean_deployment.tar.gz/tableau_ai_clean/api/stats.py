from http.server import BaseHTTPRequestHandler
import json

# Global storage for demo purposes (in production, use a database)
uploaded_workbooks = []
generated_workbooks = []

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        
        response = {
            'uploadedWorkbooks': len(uploaded_workbooks),
            'analyzedWorkbooks': len(uploaded_workbooks),
            'aiReady': len(uploaded_workbooks),
            'generatedWorkbooks': len(generated_workbooks)
        }
        
        self.wfile.write(json.dumps(response).encode())
        return

