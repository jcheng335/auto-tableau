from http.server import BaseHTTPRequestHandler
import json
import cgi
import io
from datetime import datetime

# Global storage for demo purposes (in production, use a database)
uploaded_workbooks = []

class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        return

    def do_POST(self):
        try:
            # Parse multipart form data
            content_type = self.headers.get('Content-Type', '')
            if not content_type.startswith('multipart/form-data'):
                self.send_error(400, 'Content-Type must be multipart/form-data')
                return

            # Get content length
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 100 * 1024 * 1024:  # 100MB limit
                self.send_error(413, 'File too large')
                return

            # Read the form data
            form_data = self.rfile.read(content_length)
            
            # Parse the multipart data
            env = {
                'REQUEST_METHOD': 'POST',
                'CONTENT_TYPE': content_type,
                'CONTENT_LENGTH': str(content_length)
            }
            
            form = cgi.FieldStorage(
                fp=io.BytesIO(form_data),
                environ=env,
                keep_blank_values=True
            )
            
            if 'file' not in form:
                self.send_error(400, 'No file provided')
                return
                
            file_item = form['file']
            if not file_item.filename:
                self.send_error(400, 'No file selected')
                return
            
            filename = file_item.filename
            file_data = file_item.file.read()
            
            # Validate file type
            valid_extensions = ['.twb', '.twbx', '.hyper']
            file_extension = '.' + filename.split('.')[-1].lower()
            
            if file_extension not in valid_extensions:
                self.send_error(400, 'Invalid file type')
                return
            
            # Simulate analysis
            workbook_info = {
                'id': len(uploaded_workbooks) + 1,
                'filename': filename,
                'size': len(file_data),
                'uploadedAt': datetime.now().isoformat(),
                'status': 'analyzed',
                'fields': ['Sales', 'Region', 'Category', 'Profit', 'Date'],
                'visualizations': ['Bar Chart', 'Line Chart', 'Map'],
                'dashboards': ['Sales Overview', 'Regional Analysis']
            }
            
            uploaded_workbooks.append(workbook_info)
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.end_headers()
            
            response = {
                'success': True,
                'workbook': workbook_info,
                'message': 'Workbook uploaded and analyzed successfully'
            }
            
            self.wfile.write(json.dumps(response).encode())
            
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            error_response = {'error': str(e)}
            self.wfile.write(json.dumps(error_response).encode())

