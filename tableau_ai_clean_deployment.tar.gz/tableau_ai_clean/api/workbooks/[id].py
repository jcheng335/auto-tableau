from http.server import BaseHTTPRequestHandler
import json
from urllib.parse import urlparse

# Global storage for demo purposes (in production, use a database)
generated_workbooks = []

class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        return

    def do_DELETE(self):
        try:
            # Extract workbook ID from path
            path = urlparse(self.path).path
            workbook_id = int(path.split('/')[-1])
            
            # Remove workbook from list
            global generated_workbooks
            initial_length = len(generated_workbooks)
            generated_workbooks = [wb for wb in generated_workbooks if wb['id'] != workbook_id]
            
            if len(generated_workbooks) == initial_length:
                self.send_error(404, 'Workbook not found')
                return
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.end_headers()
            
            response = {
                'success': True,
                'message': 'Workbook deleted successfully'
            }
            
            self.wfile.write(json.dumps(response).encode())
            
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            error_response = {'error': str(e)}
            self.wfile.write(json.dumps(error_response).encode())

