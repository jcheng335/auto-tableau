import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Header } from './components/Header'
import { Dashboard } from './components/Dashboard'
import { WorkbookUpload } from './components/WorkbookUpload'
import { AIGenerator } from './components/AIGenerator'
import { GeneratedWorkbooks } from './components/GeneratedWorkbooks'
import './App.css'

function App() {
  const [stats, setStats] = useState({
    uploadedWorkbooks: 0,
    analyzedWorkbooks: 0,
    aiReady: 0,
    generatedWorkbooks: 0
  })

  const updateStats = (newStats) => {
    setStats(prev => ({ ...prev, ...newStats }))
  }

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route 
              path="/" 
              element={<Dashboard stats={stats} />} 
            />
            <Route 
              path="/upload" 
              element={<WorkbookUpload updateStats={updateStats} />} 
            />
            <Route 
              path="/generate" 
              element={<AIGenerator updateStats={updateStats} />} 
            />
            <Route 
              path="/generated" 
              element={<GeneratedWorkbooks stats={stats} />} 
            />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App

