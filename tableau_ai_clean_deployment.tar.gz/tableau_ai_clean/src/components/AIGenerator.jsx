import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Sparkles, Lightbulb, CheckCircle, AlertCircle, Loader2, Download } from 'lucide-react'

export function AIGenerator({ updateStats }) {
  const [prompt, setPrompt] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generationProgress, setGenerationProgress] = useState(0)
  const [generationStatus, setGenerationStatus] = useState(null) // 'success', 'error', null
  const [generatedWorkbook, setGeneratedWorkbook] = useState(null)
  const [errorMessage, setErrorMessage] = useState('')

  const examplePrompts = [
    {
      title: "Sales Dashboard",
      prompt: "Create a sales dashboard with bar charts showing revenue by category and a line chart showing trends over time"
    },
    {
      title: "Regional Analysis", 
      prompt: "Build a regional performance analysis with maps and comparison charts"
    },
    {
      title: "Customer Analytics",
      prompt: "Design a customer analytics dashboard with segmentation and behavior analysis"
    },
    {
      title: "Financial Reporting",
      prompt: "Generate a financial reporting dashboard with KPIs and trend analysis"
    }
  ]

  const handleGenerate = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)
    setGenerationProgress(0)
    setGenerationStatus(null)
    setErrorMessage('')

    try {
      // Simulate generation progress
      const progressSteps = [
        { progress: 20, message: "Analyzing prompt..." },
        { progress: 40, message: "Mapping data fields..." },
        { progress: 60, message: "Generating visualizations..." },
        { progress: 80, message: "Creating dashboard layout..." },
        { progress: 100, message: "Finalizing workbook..." }
      ]

      for (const step of progressSteps) {
        await new Promise(resolve => setTimeout(resolve, 800))
        setGenerationProgress(step.progress)
      }

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt })
      })

      if (response.ok) {
        const result = await response.json()
        setGeneratedWorkbook(result.workbook)
        setGenerationStatus('success')

        // Update stats
        updateStats({
          generatedWorkbooks: 1
        })
      } else {
        const error = await response.json()
        setGenerationStatus('error')
        setErrorMessage(error.error || 'Generation failed')
      }

    } catch (error) {
      setGenerationStatus('error')
      setErrorMessage('Network error. Please try again.')
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDownload = async (workbookId) => {
    try {
      const response = await fetch(`/api/download/${workbookId}`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        a.download = `${generatedWorkbook.name}.twb`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      }
    } catch (error) {
      console.error('Download failed:', error)
    }
  }

  const handleExampleClick = (examplePrompt) => {
    setPrompt(examplePrompt)
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          AI Workbook Generator
        </h1>
        <p className="text-lg text-gray-600">
          Describe the workbook you want to create and let AI generate it for you
        </p>
      </div>

      {/* Generation Form */}
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5" />
            <span>Generate New Workbook</span>
          </CardTitle>
          <CardDescription>
            Describe your visualization requirements in natural language
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="prompt" className="text-base font-medium">
              Describe Your Workbook
            </Label>
            <Textarea
              id="prompt"
              placeholder="Describe the visualizations, data analysis, and dashboard layout you want..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-32 resize-none"
              disabled={isGenerating}
            />
            <p className="text-sm text-gray-500">
              Be specific about chart types, data fields, and layout preferences
            </p>
          </div>

          <Button 
            onClick={handleGenerate}
            disabled={!prompt.trim() || isGenerating}
            className="w-full bg-purple-600 hover:bg-purple-700"
            size="lg"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Workbook...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Workbook
              </>
            )}
          </Button>

          {/* Generation Progress */}
          {isGenerating && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">
                  Generating your workbook...
                </span>
                <span className="text-sm text-gray-500">
                  {generationProgress}%
                </span>
              </div>
              <Progress value={generationProgress} className="w-full" />
            </div>
          )}

          {/* Generation Status */}
          {generationStatus === 'success' && generatedWorkbook && (
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                <div className="space-y-2">
                  <p className="font-medium">Workbook generated successfully!</p>
                  <div className="text-sm space-y-1">
                    <p><strong>Name:</strong> {generatedWorkbook.name}</p>
                    <p><strong>Visualizations:</strong> {generatedWorkbook.visualizations}</p>
                    <p><strong>Size:</strong> {generatedWorkbook.size}</p>
                  </div>
                  <Button 
                    size="sm" 
                    className="mt-2"
                    onClick={() => handleDownload(generatedWorkbook.id)}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download Workbook
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {generationStatus === 'error' && (
            <Alert className="border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                {errorMessage || 'Generation failed. Please try again with a different prompt or check your connection.'}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Example Prompts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lightbulb className="h-5 w-5" />
            <span>Example Prompts</span>
          </CardTitle>
          <CardDescription>
            Click on any example to use it as a starting point
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {examplePrompts.map((example, index) => (
              <div
                key={index}
                className="p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer hover:border-gray-300"
                onClick={() => handleExampleClick(example.prompt)}
              >
                <h3 className="font-semibold text-gray-900 mb-2">
                  {example.title}
                </h3>
                <p className="text-sm text-gray-600">
                  {example.prompt}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

