import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Upload, Sparkles, FolderOpen, BarChart3, TrendingUp, Zap, FileText } from 'lucide-react'

export function Dashboard({ stats }) {
  const statCards = [
    {
      title: 'Uploaded Workbooks',
      value: stats.uploadedWorkbooks,
      icon: FileText,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Analyzed Workbooks',
      value: stats.analyzedWorkbooks,
      icon: TrendingUp,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'AI Ready',
      value: stats.aiReady,
      icon: Zap,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      title: 'Generated Workbooks',
      value: stats.generatedWorkbooks,
      icon: Sparkles,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    }
  ]

  const quickActions = [
    {
      title: 'Upload Workbook',
      description: 'Upload a TWB/TWBX file to start learning',
      icon: Upload,
      path: '/upload',
      color: 'bg-blue-600 hover:bg-blue-700',
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600'
    },
    {
      title: 'AI Generate',
      description: 'Create new workbooks with AI',
      icon: Sparkles,
      path: '/generate',
      color: 'bg-purple-600 hover:bg-purple-700',
      iconBg: 'bg-purple-100',
      iconColor: 'text-purple-600'
    },
    {
      title: 'View Generated',
      description: 'Browse your generated workbooks',
      icon: FolderOpen,
      path: '/generated',
      color: 'bg-green-600 hover:bg-green-700',
      iconBg: 'bg-green-100',
      iconColor: 'text-green-600'
    }
  ]

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4">
          <Sparkles className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900">
          AI Tableau Workbook Generator
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Upload your existing Tableau workbooks, let AI learn from them,
          and generate new workbooks from simple text prompts.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-6">
          <Link to="/upload">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Upload className="mr-2 h-5 w-5" />
              Get Started
            </Button>
          </Link>
          <Link to="/generate">
            <Button size="lg" variant="outline">
              <Sparkles className="mr-2 h-5 w-5" />
              Try AI Generation
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-full ${stat.bgColor}`}>
                    <Icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5" />
            <span>Quick Actions</span>
          </CardTitle>
          <CardDescription>
            Get started with common tasks
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {quickActions.map((action, index) => {
              const Icon = action.icon
              return (
                <Link key={index} to={action.path} className="group">
                  <div className="p-6 border rounded-lg hover:shadow-md transition-all group-hover:border-gray-300">
                    <div className={`inline-flex p-3 rounded-lg ${action.iconBg} mb-4`}>
                      <Icon className={`h-6 w-6 ${action.iconColor}`} />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {action.title}
                    </h3>
                    <p className="text-gray-600 mb-4">
                      {action.description}
                    </p>
                    <Button variant="outline" size="sm">
                      Get started →
                    </Button>
                  </div>
                </Link>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

