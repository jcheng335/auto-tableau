import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { FolderOpen, Download, Eye, Trash2, Sparkles, Calendar, BarChart3 } from 'lucide-react'

export function GeneratedWorkbooks({ stats }) {
  const [workbooks, setWorkbooks] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchWorkbooks()
  }, [])

  const fetchWorkbooks = async () => {
    try {
      const response = await fetch('/api/generated')
      if (response.ok) {
        const data = await response.json()
        setWorkbooks(data.workbooks || [])
      }
    } catch (error) {
      console.error('Failed to fetch workbooks:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleDownload = async (workbook) => {
    try {
      const response = await fetch(`/api/download/${workbook.id}`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        a.download = `${workbook.name}.twb`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      }
    } catch (error) {
      console.error('Download failed:', error)
    }
  }

  const handleDelete = async (workbookId) => {
    try {
      const response = await fetch(`/api/workbooks/${workbookId}`, {
        method: 'DELETE'
      })
      if (response.ok) {
        setWorkbooks(workbooks.filter(wb => wb.id !== workbookId))
      }
    } catch (error) {
      console.error('Delete failed:', error)
    }
  }

  const EmptyState = () => (
    <Card className="max-w-2xl mx-auto">
      <CardContent className="p-12 text-center">
        <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-6">
          <Sparkles className="h-8 w-8 text-gray-400" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          No Generated Workbooks Yet
        </h3>
        <p className="text-gray-600 mb-6 max-w-md mx-auto">
          Start by generating your first AI-powered Tableau workbook. 
          Upload a reference workbook and describe what you want to create.
        </p>
        <Link to="/generate">
          <Button className="bg-purple-600 hover:bg-purple-700">
            <Sparkles className="mr-2 h-4 w-4" />
            Generate Your First Workbook
          </Button>
        </Link>
      </CardContent>
    </Card>
  )

  const WorkbookCard = ({ workbook }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg">{workbook.name}</CardTitle>
            <CardDescription className="flex items-center space-x-4 text-sm">
              <span className="flex items-center">
                <Calendar className="mr-1 h-3 w-3" />
                {new Date(workbook.createdAt).toLocaleDateString()}
              </span>
              <span className="flex items-center">
                <BarChart3 className="mr-1 h-3 w-3" />
                {workbook.visualizations} charts
              </span>
            </CardDescription>
          </div>
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            Ready
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <p className="text-sm text-gray-700 font-medium mb-1">Original Prompt:</p>
          <p className="text-sm text-gray-600">{workbook.prompt}</p>
        </div>
        
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>Size: {workbook.size}</span>
          <span>Generated with AI</span>
        </div>

        <div className="flex space-x-2">
          <Button 
            size="sm" 
            className="flex-1"
            onClick={() => handleDownload(workbook)}
          >
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
          <Button size="sm" variant="outline">
            <Eye className="mr-2 h-4 w-4" />
            Preview
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            className="text-red-600 hover:text-red-700"
            onClick={() => handleDelete(workbook.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading workbooks...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Generated Workbooks
        </h1>
        <p className="text-lg text-gray-600">
          Browse and download your AI-generated Tableau workbooks
        </p>
      </div>

      {workbooks.length === 0 ? (
        <EmptyState />
      ) : (
        <>
          {/* Stats Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-gray-900">{workbooks.length}</div>
                <div className="text-sm text-gray-600">Total Generated</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {workbooks.reduce((sum, wb) => sum + (wb.visualizations || 0), 0)}
                </div>
                <div className="text-sm text-gray-600">Total Visualizations</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {workbooks.reduce((sum, wb) => sum + parseFloat(wb.size || '0'), 0).toFixed(1)}MB
                </div>
                <div className="text-sm text-gray-600">Total Size</div>
              </CardContent>
            </Card>
          </div>

          {/* Workbooks Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {workbooks.map((workbook) => (
              <WorkbookCard key={workbook.id} workbook={workbook} />
            ))}
          </div>

          {/* Actions */}
          <div className="text-center">
            <Link to="/generate">
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                <Sparkles className="mr-2 h-5 w-5" />
                Generate Another Workbook
              </Button>
            </Link>
          </div>
        </>
      )}
    </div>
  )
}

