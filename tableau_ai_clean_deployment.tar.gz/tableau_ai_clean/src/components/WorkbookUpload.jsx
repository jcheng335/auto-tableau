import { useState, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Upload, FileText, Database, Package, CheckCircle, AlertCircle, Loader2 } from 'lucide-react'

export function WorkbookUpload({ updateStats }) {
  const [dragActive, setDragActive] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState(null) // 'success', 'error', null
  const [uploadedFile, setUploadedFile] = useState(null)
  const [errorMessage, setErrorMessage] = useState('')

  const handleDrag = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }, [])

  const handleFileInput = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const handleFile = async (file) => {
    // Validate file type
    const validExtensions = ['.twb', '.twbx', '.hyper']
    const fileExtension = '.' + file.name.split('.').pop().toLowerCase()
    
    if (!validExtensions.includes(fileExtension)) {
      setUploadStatus('error')
      setErrorMessage('Invalid file type. Please upload a TWB, TWBX, or HYPER file.')
      return
    }

    // Validate file size (100MB limit)
    if (file.size > 100 * 1024 * 1024) {
      setUploadStatus('error')
      setErrorMessage('File too large. Maximum size is 100MB.')
      return
    }

    setIsUploading(true)
    setUploadProgress(0)
    setUploadStatus(null)
    setUploadedFile(file)
    setErrorMessage('')

    try {
      const formData = new FormData()
      formData.append('file', file)

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + Math.random() * 20
        })
      }, 200)

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      })

      clearInterval(progressInterval)
      setUploadProgress(100)

      if (response.ok) {
        const result = await response.json()
        setUploadStatus('success')
        
        // Update stats
        updateStats({
          uploadedWorkbooks: 1,
          analyzedWorkbooks: 1,
          aiReady: 1
        })
      } else {
        const error = await response.json()
        setUploadStatus('error')
        setErrorMessage(error.error || 'Upload failed')
      }
      
    } catch (error) {
      setUploadStatus('error')
      setErrorMessage('Network error. Please try again.')
    } finally {
      setIsUploading(false)
    }
  }

  const fileTypes = [
    {
      extension: 'TWB Files',
      description: 'Tableau Workbook files containing visualizations, dashboards, and metadata',
      icon: FileText,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      extension: 'TWBX Files',
      description: 'Packaged Tableau Workbooks including data extracts and resources',
      icon: Package,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      extension: 'HYPER Files',
      description: 'Tableau data extracts from Alteryx or other data preparation tools',
      icon: Database,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    }
  ]

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Upload Tableau Workbook
        </h1>
        <p className="text-lg text-gray-600">
          Upload your TWB, TWBX, or HYPER files to start the AI learning process
        </p>
      </div>

      {/* Upload Area */}
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-8">
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-300 hover:border-gray-400'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="space-y-4">
              <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                <Upload className="h-8 w-8 text-gray-600" />
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Drop your Tableau file here
                </h3>
                <p className="text-gray-600 mb-4">
                  or click to browse and select a file
                </p>
                
                <input
                  type="file"
                  accept=".twb,.twbx,.hyper"
                  onChange={handleFileInput}
                  className="hidden"
                  id="file-upload"
                  disabled={isUploading}
                />
                <label htmlFor="file-upload">
                  <Button asChild disabled={isUploading}>
                    <span className="cursor-pointer">
                      <Upload className="mr-2 h-4 w-4" />
                      Choose File
                    </span>
                  </Button>
                </label>
              </div>
              
              <p className="text-sm text-gray-500">
                Supported formats: TWB, TWBX, HYPER • Max size: 100MB
              </p>
            </div>
          </div>

          {/* Upload Progress */}
          {isUploading && (
            <div className="mt-6 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">
                  Uploading {uploadedFile?.name}...
                </span>
                <span className="text-sm text-gray-500">
                  {Math.round(uploadProgress)}%
                </span>
              </div>
              <Progress value={uploadProgress} className="w-full" />
            </div>
          )}

          {/* Upload Status */}
          {uploadStatus === 'success' && (
            <Alert className="mt-6 border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                File uploaded successfully! Your workbook has been analyzed and is ready for AI generation.
              </AlertDescription>
            </Alert>
          )}

          {uploadStatus === 'error' && (
            <Alert className="mt-6 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                {errorMessage || 'Upload failed. Please check that your file is a valid TWB, TWBX, or HYPER file under 100MB.'}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Supported File Types */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileText className="h-5 w-5" />
            <span>Supported File Types</span>
          </CardTitle>
          <CardDescription>
            Learn about the different Tableau file formats you can upload
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {fileTypes.map((type, index) => {
              const Icon = type.icon
              return (
                <div key={index} className="text-center p-4">
                  <div className={`inline-flex p-4 rounded-full ${type.bgColor} mb-4`}>
                    <Icon className={`h-8 w-8 ${type.color}`} />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {type.extension}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {type.description}
                  </p>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

